<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_Hadasa_Geiger_traveler
 */

?>

	</div><!-- #content -->
 <div class="parallax"></div>
  <div class="container" style="width: 80%;margin-top: 50px;margin-bottom: 30px; ">
		<div class="row">
			<div class="col-md-3 col-sm-6">
				<a href="#">
					<img src="https://image.freepik.com/free-icon/facebook-logo-with-rounded-corners_318-9850.jpg" width="100" style="margin-left: 70px;">
				</a>
				<h3 class="text-center">FaceBook</h3>
			</div>
			<div class="col-md-3 col-sm-6">
				<a href="#">
					<img src="https://image.freepik.com/free-icon/twitter-logo_318-40459.jpg" width="100" style="margin-left: 70px;">
				</a>
				<h3 class="text-center">Twitter</h3>
			</div>
			<div class="col-md-3 col-sm-6">
				<a href="#">
					<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSyJLYp0nSyZHNQv4qt5uVM0G3O7J37-0IjHV2Xpyobs6AG5juI-A" width="100" style="margin-left: 70px;">
				</a>
				<h3 class="text-center">GitHub</h3>
			</div>
			<div class="col-md-3 col-sm-6">
				<div id="myCarousel" class="carousel slide" data-ride="carousel">
          <!-- Indicators -->
          <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <div class="item active">
              <img src="http://veva.cz/upload/images/first-mountain-trip.jpg" alt="Los Angeles" width="100%" style="height: 160px;">
            </div>

            <div class="item">
              <img src="https://mountaintrip.com/wp-content/uploads/2013/10/CO-page-_6.jpg" alt="Chicago" width="100%" style="height: 160px;">
            </div>
          
            <div class="item">
              <img src="https://www.rei.com/adventures/assets/adventures/images/trip/core/europe/tmb_hero" alt="New york" width="100%" style="height: 160px;">
            </div>
          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
          </a>
        </div>
			</div>
		</div>
	</div>


<footer class="blog-footer text-center jumbotron">
     	<h4> &copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?></h4>
     	<h4>
       		<a href="#">Back to top</a>
     	</h4>
   </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
